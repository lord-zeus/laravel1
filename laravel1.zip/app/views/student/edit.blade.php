@extends('layout.main')
@section('content')
    {{Form::model($list, array('route'=>['student.update', $list->id], 'method'=>'PUT'))}}
        @include('student.partials._form')
    {{Form::submit('Update', array('class'=>'waves-effect waves-light btn btn-mid'))}}
    {{Form::close()}}

@stop