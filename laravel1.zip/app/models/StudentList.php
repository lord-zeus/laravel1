<?php
class StudentList extends Eloquent{
    public function taskItems(){
        return $this->hasMany('StudentTask');
    }

}