@extends('layout.main')
@section('content')
    {{Form::open(array('route'=>'student.store'))}}
        @include('student.partials._form')
        {{Form::submit('Submit', array('class'=>'waves-effect waves-light btn btn-mid'))}}
    {{Form::close()}}

@stop