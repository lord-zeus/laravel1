<?php
class StudentTask extends Eloquent{
    public function studentList(){
        return $this->belongsTo('StudentList');
    }

}