 // this is for a drop down 
 $('.dropdown-button').dropdown({
      inDuration: 300,
      outDuration: 225,
      constrain_width: false, // Does not change width of dropdown to that of the activator
      hover: false, // Activate on hover
      gutter: 0, // Spacing from edge
      belowOrigin: false, // Displays dropdown below the button
      alignment: 'left' // Displays dropdown with edge aligned to the left of button
    }
  );


 // for enlargable images to help zoom them
  $(document).ready(function(){
    $('.materialboxed').materialbox();
  });
   $(document).ready(function(){
      $('.slider').slider({full_width: true});
      $('.slider').slider({indicators: false});
    });


  //for medals 
  $(document).ready(function(){
    // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
    $('.modal-trigger').leanModal({
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: .5, // Opacity of modal background
      in_duration: 300, // Transition in duration
      out_duration: 200, // Transition out duration
      ready: function() { alert('Ready'); }, // Callback for Modal open
      complete: function() { alert('Closed'); } // Callback for Modal close
    }
    );
   // $('#modal1').openModal();
  // $('#modal1').closeModal();
  });




  //for Parallax Images
  $(document).ready(function(){
      $('.parallax').parallax();

    });

//pushing used for fixed possitioning
  $(document).ready(function(){
    $('.tabs-wrapper .row').pushpin({ top: $('.tabs-wrapper').offset().top });
  });


  //scroll fire to unleach things as your scroll downwards

var options = [
    {selector: '.class', offset: 200, callback: 'globalFunction()' },
    {selector: '.other-class', offset: 200, callback: 'globalFunction()' },
  ];
  Materialize.scrollFire(options);


  // Initialize collapse button
  $('.button-collapse').sideNav({
      menuWidth: 300, // Default is 240
      edge: 'right', // Choose the horizontal origin
      closeOnClick: true // Closes side-nav on <a> clicks, useful for Angular/Meteor
    }
  );
  // Initialize collapsible (uncomment the line below if you use the dropdown variation)
  //$('.collapsible').collapsible();
        

  // Show sideNav
$('.button-collapse').sideNav('show');


//for forms 
$('#textarea1').val('New Text');
  $('#textarea1').trigger('autoresize');

//for selecting elements as shown below
  $(document).ready(function() {
    $('select').material_select();
  });

  //for picking dates
   $('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15 // Creates a dropdown of 15 years to control year
  });

   // scrollspy is to keep track of every thing going on so that it shows the location of the user on the page
   $(document).ready(function(){
    $('.scrollspy').scrollSpy();
  });