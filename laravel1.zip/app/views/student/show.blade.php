@extends('layout.main')
@section('content')

    <h2>Selected Student</h2>
    <h5>{{{$list->name}}}</h5>
    @foreach($items as $item)
        <h6>{{{$item->task}}}</h6>
    @endforeach
    {{link_to_route('student.index', 'Home', null, ['class'=>'waves-effect waves-light btn'])}}


@stop