<?php

class StudentListController extends \BaseController {

	public function __contruct(){
		$this->beforeFilter('csrf', array('on'=>'post'));
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$student_lists = StudentList::all();
		return View::make('student.index')->with('student_lists', $student_lists);
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('student.create');
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$rules = array(
			'name' =>'required',
			'validate' =>array('required', 'unique:student_lists,email'),
			'school' =>'required'
		);

		$validator = Validator::make(Input::all(), $rules);

		if($validator->fails()){
				return Redirect::route('student.create')->withErrors($validator)->withInput();
		}


		$name = Input::get('name');
		$email = Input::get('validate');
		$school = Input::get('school');
		$list = new StudentList();
		$list->name =$name;
		$list->email =$email;
		$list->school =$school;
		$list->save();

		return Redirect::route('student.index')->withMessage('Student has been added');
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$list = StudentList::find($id);
		$items = $list->taskItems()->get();
		return View::make('student.show')
			->withList($list)
			->withItems($items);
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{

		$list =StudentList::findOrFail($id);
		return View::make('student.edit')->withList($list);
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$rules = array(
			'name' =>'required',
			'validate' =>array('required', 'unique:student_lists,email'),
			'school' =>'required'
		);

		$validator = Validator::make(Input::all(), $rules);

		if($validator->fails()){
			return Redirect::route('student.edit', $id)->withErrors($validator)->withInput();
		}


		$name = Input::get('name');
		$email = Input::get('validate');
		$school = Input::get('school');
		$list = StudentList::findOrFail($id);
		$list->name =$name;
		$list->email =$email;
		$list->school =$school;
		$list->update();

		return Redirect::route('student.index')->withMessage('Student has been Updated');
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$student_lists = StudentList::findOrFail($id)->delete();
		return Redirect::route('student.index')->withMessage('Student has been Deleted');
	}


}
