<div class="input-field">
    {{Form::label('name', 'Name')}}
    {{Form::text('name')}}
    {{$errors->first('name')}}<br>
</div>
<div class="input-field">
    {{Form::label('email', 'Email')}}
    {{Form::email('validate')}}
    {{$errors->first('validate')}}<br>
</div>
<div class="input-field">
    {{Form::label('school', 'School')}}
    {{Form::text('school')}}
    {{$errors->first('school')}}
</div>