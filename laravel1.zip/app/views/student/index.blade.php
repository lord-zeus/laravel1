@extends('layout.main')
@section('content')

    <h2>List Of All Students</h2>
    <table class="highlight">
        <thead>
            <tr>
                <th data-field="name">Name</th>
                <th data-field="email">Email</th>
                <th data-field="school">School</th>
                <th data-field="option">Options</th>
            </tr>
        </thead>
        <tbody>
            @foreach($student_lists as $list)
                <tr>
                    <td>{{link_to_route('student.show', $list->name, [$list->id])}}</td>
                    <td>{{{$list->email}}}</td>
                    <td>{{{$list->school}}}</td>
                    <td>{{link_to_route('student.edit', 'Edit', $list->id, ['class'=>'btn-floating btn-large waves-effect waves-light blue'])}}
                    {{ Form::model($list, ['route' => ['student.destroy', $list->id ], 'method'=>'DELETE'])}}
                        {{Form::button('DELETE', ['type'=>'submit','class'=>'btn-floating btn-large waves-effect waves-light red'])}}
                    {{Form::close() }}

                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{link_to_route('student.create', 'Add', null, ['class'=>'yellow darken-2 btn-floating btn-large waves-effect waves-yellow darken-2'])}}

@stop