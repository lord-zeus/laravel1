<!doctype html>
<html lang="en">
<head>
    <link rel="stylesheet" href="{{asset('css/materialize.min.css')}}">
    <link rel="stylesheet" href="{{asset('fonts/material-design-icons/')}}">
    <link rel="stylesheet" href="{{asset('fonts/roboto/')}}">
    <meta charset="UTF-8">
    <title>Njorku</title>
</head>
<body>
<div class="navbar-fixed teal darken-4">
    <nav>
        <div class="nav-wrapper teal darken-4 row">
           <div>{{link_to_route('student.index','Welcome To Njorku', null,  ['class'=>'waves-effect col l2  teal darken-4'])}}</div>
           <div> {{link_to_route('student.create', 'Registration', null, ['class'=>' waves-effect col l2 offset-l8 teal darken-4 right-align'])}}</div>
        </div>
    </nav>
</div>

    @if(Session::has('message'))
        <div class="row card-panel blue darken-4 ">
        <div class="blue darken-4 col l2 offset-l10">
            {{{Session::get('message')}}}
        </div>
    </div>
    @endif


<div class="row container">
    <div class="col l12 m12 l6">
        @yield('content')
    </div>
</div>
<footer class="page-footer teal darken-4">
    <div class="container">
       Zeus © 2016 Copyright
    </div>
</footer>



{{--<script src="{{asset('js/jquery.js')}}"></script>--}}
{{HTML::script('js/jquery.js')}}
{{HTML::script('js/materialize.min.js')}}

{{--<script src="{{asset('js/materialize.min.js')}}"></script>--}}

</body>
</html>
